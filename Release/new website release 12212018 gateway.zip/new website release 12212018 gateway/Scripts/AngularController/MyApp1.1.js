﻿(function () {
    //create module
    var app = angular.module('MyApp', ['ngCookies', 'ngRoute', 'ngDialog', 'ngTable', 'ui.bootstrap', 'ui', 'ngSanitize', 'uiGmapgoogle-maps']);
})();